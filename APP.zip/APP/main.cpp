#include <iostream>
#include <fstream>
#include <vector>
#include <stdlib.h>

#include "Item.cpp"
#include "ShoppingC.cpp"
#include "Bottoms.cpp"
#include "Top.cpp"
#include "Client.cpp"
using namespace std;

template <typename S>
ostream& operator<<(ostream& os,
                    const vector<S>& vector)
{
    // Printing all the elements
    // using <<
    for (auto element : vector) {
        os << element << " ";
    }
    return os;
}

int main()
{
    vector<Item*>items;
    items.push_back(new Bottoms("Jeans","32",5));
    items.push_back(new Top("T-shirt","S",3));
    items.push_back(new Bottoms("Skirt","36",3));
    items.push_back(new Top("Blouse","M",5));

    Client C1;
    Client C2("Anastasia R","anasr@icloud.com");
    int op1,op2;

    cout<<"Select an option\n1.Log in\n2.Exit\n"<<endl;
    cout<<"Option--: ";
    cin>>op1;

    string res;
    if(op1==1){
        cout<<"Enter your name: ";
        cin>>res;
        C1.setName(res);
        cout<<"Enter your email: ";
        cin>>res;
        C1.setEmail(res);

        cout<<"\n\tNew Arrivals"<<endl;
        cout<<""<<endl;
        int id;

        vector<Item*>::const_iterator i;
        for (i=items.begin();i!=items.end();++i)
        {
            cout<<(*i)->Show()<<endl;
            cout<<"ID item: "<<(*i)->IDitem()<<endl;
        }
        char opt1,opt2;
        cout<<"\nWould you like to add something to your Shopping Car (Y/N): ";
        cin>>opt1;
            if (opt1=='Y'||opt1=='y')
            {
                cout<<"\nWhich item would you like to add to your car? Insert ID: ";
                cin>>res;
                ShoppingC shop;
                shop.AddItem(res);

                cout<<"Your shopping car has: ";
                vector<Item*>::const_iterator i;
                for (i=items.begin();i!=items.end();++i)
                {
                    int x;
                    if (x!=1)
                        cout<<(*i)->getItem(shop.AddItem(res))<<endl;
                        x=1;
                }
                cout<<C1.getOrder();
                opt1='N';
            }
            else
                cout<<"Do you want to log out? (Y/N): ";
                cin>>opt2;
                if (opt2=='Y'||opt2=='y')
                    op2 = 2;
                else
                    cout<<"Keep looking!"<<endl;
    }
    else
        if(op2==2)
            cout<<"See you soon!"<<endl;
        else
            cout<<"Invalid option, try again"<<endl;


    return 0;
}
