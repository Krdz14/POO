#ifndef ITEM_CPP
#define ITEM_CPP

#include <iostream>
#include <vector>
using namespace std;


class Item
{
    public:
        Item(string,int);
        virtual string Show()=0;
        virtual int IDitem()=0;
        virtual string getItem(string)=0;

    protected:
        string sizes;
        int quantity;
    private:

};

Item::Item(string s, int n)
{
    sizes = s;
    quantity = n;
}

#endif

