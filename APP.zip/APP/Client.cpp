#ifndef CLIENT_CPP
#define CLIENT_CPP

#include "ShoppingC.cpp"
using namespace std;
#include <iostream>

class Client
{
    public:
        Client();
        Client(string,string);
        string getOrder();
        void setName(string);
        void setEmail(string);

    protected:

    private:
        string name;
        string email;
        ShoppingC order;
};


Client::Client()
{
    name = "No user";
    email= "No email";
}

Client::Client(string n,string e)
{
    name = n;
    email = e;
}

void Client::setName(string n)
{
    name = n;
}

void Client::setEmail(string e)
{
    email = e;
}

string Client::getOrder()
{
    return order.showCar();
}

#endif
