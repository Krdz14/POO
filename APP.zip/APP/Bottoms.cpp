#ifndef BOTTOMS_CPP
#define BOTTOMS_CPP

#include "Item.cpp"


class Bottoms : public Item
{
    public:
        Bottoms(string, string, int);
        string Show() override;
        int IDitem() override;
        string getItem(string) override;

    protected:

    private:
        string Bottom;
        int id;
};

Bottoms::Bottoms(string n, string s, int q):Item(s,q)
{
    Bottom = n;
}

string Bottoms::Show()
{
    string present;
    present = "Item: " + Bottom + ", Size: " + sizes;
    return present;
}

int Bottoms::IDitem()
{
    id = rand();
    return id;
}
string Bottoms::getItem(string x)
{
    while (x==to_string(id))
    {
        return Bottom;
        break;
    }
}


#endif
