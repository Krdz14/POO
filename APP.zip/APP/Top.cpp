#ifndef TOP_CPP
#define TOP_CPP

#include "Item.cpp"

class Top: public Item
{
    public:
        Top();
        Top(string, string, int);
        string Show() override;
        int IDitem() override;
        string getItem(string) override;

    protected:

    private:
        string tops;
        int id;
};

Top::Top(string n, string s, int q):Item(s,q)
{
    tops = n;
}

string Top::Show()
{
    string present;
    present = "Item: " + tops + ", Size: " + sizes;
    return present;
}
int Top::IDitem()
{
    id = rand();
    return id;
}

string Top::getItem(string x)
{
    while (x==to_string(id))
    {
        return tops;
        break;
    }
}


#endif
