#ifndef SHOPPINGC_CPP
#define SHOPPINGC_CPP

#include "Bottoms.cpp"
#include "Top.cpp"
#include "Item.cpp"

#include <iostream>
#include <string>
#include <sstream>
using namespace std;

class ShoppingC
{
    public:
        string AddItem(string);
        string showCar();

    protected:

    private:
        string ShoppingCar;
};

string ShoppingC::showCar()
{
    return ShoppingCar;
}

string ShoppingC::AddItem(string x)
{
    ShoppingCar = x;
    return ShoppingCar;
}

#endif
